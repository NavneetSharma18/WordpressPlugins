<?php


class nkt_admin_customization {  

    

    public function __construct() {
      
     add_action('restrict_manage_users', array($this,'add_course_section_filter')); 
     add_filter('pre_get_users', array($this,'filter_users_by_course_section') );

    }


    public function add_course_section_filter( $which ) {

		    // create sprintf templates for <select> and <option>s
		    $st = '<select name="course_section_%s" style="float:none;"><option value="">%s</option>%s</select>';
		    $ot = '<option value="%s" %s>Section %s</option>';

		    // determine which filter button was clicked, if any and set section
		    $button = key( array_filter( $_GET, function($v) { return __( 'Filter' ) === $v; } ) );
		    $section = $_GET[ 'course_section_' . $button ] ?? -1;

		    // generate <option> and <select> code
		    $options = implode( '', array_map( function($i) use ( $ot, $section ) {
		        return sprintf( $ot, $i, selected( $i, $section, false ), $i );
		    }, range( 1, 3 ) ));
		    $select = sprintf( $st, $which, __( 'Course Section...' ), $options );

		    // output <select> and submit button
		    echo $select;
		    submit_button(__( 'Filter' ), null, $which, false);
		}


	public	function filter_users_by_course_section($query)
		{
		    global $pagenow;
		    if (is_admin() && 'users.php' == $pagenow) {
		        $button = key( array_filter( $_GET, function($v) { return __( 'Filter' ) === $v; } ) );
		        if ($section = $_GET[ 'course_section_' . $button ]) {
		            $meta_query = [['key' => 'courses','value' => $section, 'compare' => 'LIKE']];
		            $query->set('meta_key', 'courses');
		            $query->set('meta_query', $meta_query);
		        }
		    }
		}

  

}

new nkt_admin_customization();
