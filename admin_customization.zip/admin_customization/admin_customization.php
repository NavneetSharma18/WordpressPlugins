<?php

/*

 * Plugin Name: Customization Admin Dashboard

 * Plugin URI: http://nktechnologys.com/

 * Description: This plugin is use for customize the functionality of admin dashboard

 * Author: Kiran Polist

 * Text Domain: http://nktechnologys.com/

 * Version: 1.0

 * Requires at least: 4.4

 * Tested up to: 5.2.2

 */

defined( 'ABSPATH' ) or exit;

if (!function_exists('pr')) {
    function pr($data) {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}



add_action('plugins_loaded', 'load_nkt_urlshorten_plugin');

function load_nkt_urlshorten_plugin() {
    define('NKT_US_PLUGIN_URL', plugin_dir_url(__FILE__));
    define('NKT_US_PLUGIN_DIR', plugin_dir_path(__FILE__));
   

    require_once NKT_US_PLUGIN_DIR . '/inc/loader.php';
    
}



/*  Activation hook */
register_activation_hook(__FILE__, 'nkt_us_activate_print');

function nkt_us_activate_print() {

   
 
    
}

/*  Deactivation hook  */
register_deactivation_hook(__FILE__, 'nkt_us_deactivation_event');

function nkt_us_deactivation_event() {

}

/*  Uninstalled hook  */
function nkt_us_plugin_uninstall(){
    
}

register_uninstall_hook(__FILE__, 'nkt_us_plugin_uninstall');




?>