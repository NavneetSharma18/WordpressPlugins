<?php

class NktImportAgent {  

    
   /*---------------------------------------------------------
   |  Construct function for adding hook
   ----------------------------------------------------------*/

    public function __construct() {
        
     add_action( 'admin_menu', array($this,'nk_add_admin_page') );
     add_action( 'wp_ajax_nopriv_add_tag_data', array($this,'add_tag_data') );
     add_action( 'wp_ajax_add_tag_data', array($this,'add_tag_data' ) );


    }

    /*---------------------------------------------------------
    |  Adding new tags
    ----------------------------------------------------------*/

    public function slugify($text)
    {
      // replace non letter or digits by -
      $text = preg_replace('~[^\pL\d]+~u', '-', $text);

      // transliterate
      $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

      // remove unwanted characters
      $text = preg_replace('~[^-\w]+~', '', $text);

      // trim
      $text = trim($text, '-');

      // remove duplicate -
      $text = preg_replace('~-+~', '-', $text);

      // lowercase
      $text = strtolower($text);

      if (empty($text)) {
        return 'n-a';
      }

      return $text;
    }



    
    /*---------------------------------------------------------
    |  Adding new tags
    ----------------------------------------------------------*/

    public function add_tag_data(){

        $data   = [];



        if(isset($_FILES['file']) && !empty($_FILES['file']) ){


                $csv_mimetypes = array(
                    'text/csv',
                    'text/plain',
                    'application/csv',
                    'text/comma-separated-values',
                    'application/excel',
                    'application/vnd.ms-excel',
                    'application/vnd.msexcel',
                    'text/anytext',
                    'application/octet-stream',
                    'application/txt',
                );

                if (in_array($_FILES['file']['type'], $csv_mimetypes)) {


                        
                        /*-------------------------------------------
                        |  Read CSV files
                        ---------------------------------------------*/

                        $csvFile = file($_FILES['file']['tmp_name']);
                        $data    = [];

                        foreach ($csvFile as $line) {
                            $data[] = str_getcsv($line);
                        }


                      

                        if(isset($data) && count($data) > 0 ){

                            $totalRecImported = 0;
                            $current_user     = wp_get_current_user();
                            $author_id        = $current_user->ID;

                            foreach ($data as $key => $value) {


                                                                // if csv have heading then skip

                               if($key == 0){ continue; }

                                $title        = ( isset($value[0]) )?$value[0]:'';
                                $name         = ( isset($value[1]) )?$value[1]:'';
                                $tel          = ( isset($value[2]) )?$value[2]:'';
                                $email        = ( isset($value[3]) )?$value[3]:'';
                                $token        = ( isset($value[4]) )?$value[4]:'';
                                $invoice_name = ( isset($value[5]) )?$value[5]:'';
                                $client_order = ( isset($value[6]) )?$value[6]:'';


                                $validEmail = false;
                                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                  $validEmail = true;
                                }

                                // if email is not found in csv record then skip

                                if(null != $email || $validEmail == true){

                                          $client_order_s= array($client_order);                                         
                                
                                          $args = array(
                                              'posts_per_page'  => '-1',
                                              'post_type'       => 'client',
                                              'post_status'     => 'publish',
                                              'meta_key'        => 'email',
                                              'meta_value'      => $email,
                                              'author'          => $author_id
                                          );

                                          // query

                                          $the_query = new WP_Query( $args );

                                          if( $the_query->have_posts() ){

                                              // post already exist with smae email and agent id then skip
                                              continue;
                                              
                                          }else{
                                              
                                            
                                              $my_post = array(
                                                  'post_title'    => $title,
                                                  'post_content'  => '',
                                                  'post_status'   => 'publish',
                                                  'post_author'   => $author_id,
                                                  'post_type'     => 'client'
                                              );
                                              
                                              
                                              $result = wp_insert_post( $my_post );

                                              if ( $result && ! is_wp_error( $result ) ) {
                                                  $client_id = $result;

                                                  update_field('name',$name,$client_id);
                                                  update_field('email',$email,$client_id);
                                                  update_field('tel',$tel,$client_id);
                                                  update_field('token',$token,$client_id);                               
                                                  update_field('client_orders',$client_order_s,$client_id);
                                                  update_field('invoice_name',$invoice_name,$client_id);

                                                 
                                              }
                                            
                                          

                                          }

                                          wp_reset_query();

                                          $totalRecImported++; 

                                }else{
                                  continue;
                                }

  
                            } // endforeach

                            $data['status']  = true;
                            $data['options'] = "Total $totalRecImported :- Record has been imported!";


                        }else{
                                $data['status']  = false;
                                $data['options'] = "No data found in CSV, please try with another csv"; 
                        }
                       

                }else{
                     $data['status']  = false;
                     $data['options'] = "Invalid file type, allowed only CSV file";
                }

            

        }else{
             $data['status']  = false;
             $data['options'] = "Please select the required filed";
        }

        echo json_encode($data); 
        exit;
    }


   /*---------------------------------------------------------
    |  Plugin add admin menu page
    ----------------------------------------------------------*/

    public function nk_add_admin_page(){


        global $user_role_name;
        
        if( $user_role_name == 'contributor' || $user_role_name == 'caravan_owner' ){

            add_menu_page( 'Import Client', 'Import Client', 'manage_import_csv_users', 'nkt_imported_agent_list', array($this,'nkt_imported_agent_list'));
        }

        

        
    }


    /*---------------------------------------------------------
    |  List all imported Client
    ----------------------------------------------------------*/

    public function nkt_imported_agent_list(){

        ob_start();
        require_once NKT_US_PLUGIN_DIR . '/inc/template/agentlist.php';
        $agents_list = ob_get_contents();
        ob_end_clean(); 
        echo $agents_list;

    }



    
   

}

new NktImportAgent();