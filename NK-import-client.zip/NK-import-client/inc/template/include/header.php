<?php ?>

<link rel="stylesheet" type="text/css" href="<?= NKT_US_PLUGIN_URL .'inc/template/include/css/jquery.dataTables.min.css' ?>">
<link rel="stylesheet" href="<?= NKT_US_PLUGIN_URL .'inc/template/include/css/bootstrap.min.css'?>">
<link href="<?= NKT_US_PLUGIN_URL .'inc/template/include/css/toastr.css'?>" rel="stylesheet"/>
<link href="<?= NKT_US_PLUGIN_URL .'inc/template/include/css/style.css'?>" rel="stylesheet"/>
<script type="text/javascript">
	var admin_url = "<?= admin_url('admin-ajax.php') ?>";
</script>