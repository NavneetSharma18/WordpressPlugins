<script src="<?= NKT_US_PLUGIN_URL .'inc/template/include/js/jquery.min.js'?>"></script>
<script src="<?= NKT_US_PLUGIN_URL .'inc/template/include/js/bootstrap.min.js'?>"></script>
<script type="text/javascript" src="<?= NKT_US_PLUGIN_URL .'inc/template/include/js/jquery.dataTables.min.js'?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>

<script src="<?= NKT_US_PLUGIN_URL .'inc/template/include/js/toastr.js'?>"></script>
<script src="<?= NKT_US_PLUGIN_URL .'inc/template/include/js/jquery.validate.js'?>"></script>
<script src="<?= NKT_US_PLUGIN_URL .'inc/template/include/js/custom.js'?>"></script>