 /*-------------------------------------------------------------
  |  Intialize datatable
  -------------------------------------------------------------*/

      $(document).ready(function () {
          $('#loader').hide();
          $('#tag_tbl').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });


           $('#tag_view_data').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            } );

             

      /*-------------------------------------------------------------
      |  Get Tag Options
      -------------------------------------------------------------*/

      $("#add_tags").click(function(){
        
         $('#myModal').modal('show');
        
        
      });


      /*-------------------------------------------------------------
      |  Add Tag
      -------------------------------------------------------------*/

      $("#submit_tag").click(function(){

        
          var file_data = $('#upload_csv').prop('files')[0];   
          var form_data = new FormData();                  
          form_data.append('file', file_data);
          form_data.append('action', 'add_tag_data');
           
           if(file_data){

               $('#loader').show();

                $.ajax({
                  url:admin_url,
                  cache: false,
                  contentType: false,
                  processData: false,
                  data: form_data,                         
                  type: 'POST',
                  dataType:"json",
                  
                  success: function(res) {

                    $('#loader').hide();
                    
                    if(res.status == true){
                      toastr.success(res.options);
					location.reload();
                      
                    }else{
                       toastr.error(res.options);
                    }
                }
               });

           }else{

             
             toastr.error('Please select csv file');
           }                            

       

        



      })

});