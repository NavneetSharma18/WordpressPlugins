<?php
require_once NKT_US_PLUGIN_DIR . '/inc/template/include/header.php';
$tag_alls = [];
?>

<div class="table_container">
   <a href="data:text/csv;charset=utf-8,title,name,tel,email,token,invoice_name,client_orders,
øàåáïøàåáï,kiran,7777777777,kiranpolist68642@gmail.com,k1001,testinvoice,11455" download="sample.csv"><button class="btn btn-success">Download Sample CSV</button></a>

<div class="row">

   <div class="col-md-12 mt-5 mb-5">

        <div class="main_div" style="width: 100%;max-width: 60%;margin: 0px auto;text-align: center;padding: 35px;">
          <form action="javascript:void(0);" enctype="multipart/form-data" method="post" id="add_tag_form">

            <div class="form-group" style="border: 2px dotted;padding: 30px;margin: 30px;">
              <div class="row">

                <div class="col-md-12">
                  <label for="email">Select CSV file for import :</label>
                </div>
                <div class="col-md-12">
                   <input type="file" name="upload_csv" id="upload_csv" class="form-control" style="width: 42%;text-align: center;margin: 0px auto;">

                </div>

                 <div class="col-md-12">
                    <button type="button" class="btn btn-success" id="submit_tag" style="margin-top: 30px;">Submit</button>
                </div>
                
              </div>
             
              
            </div>
           
          
          </form>

        </div>
    
  </div>
  
</div>
 

</div>

<div id="loader">
</div>




<style type="text/css">
  	 #loader {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.75) url("<?php echo plugin_dir_url( __FILE__ ) .'/assest/loading.gif'; ?>") no-repeat center center;
            z-index: 10000;
        }
  </style>

<?php
require_once NKT_US_PLUGIN_DIR . '/inc/template/include/footer.php';
?>