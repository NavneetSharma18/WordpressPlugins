<?php

/*

 * Plugin Name: Import Client

 * Plugin URI: 

 * Description: This plugin is used for import client on login of agent dashbaord via CSV file.

 * Author: Kiran (kiranpolist6864@gmail.com)

 * Text Domain: 

 * Version: 1.0

 * Requires at least: 5.4

 * Tested up to: 6.1.1

 */

defined( 'ABSPATH' ) or exit;

if (!function_exists('pr')) {
    function pr($data) {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}


/*-------------------------------------------------------------------
| Load Core Files 
 --------------------------------------------------------------------*/

add_action('plugins_loaded', 'load_nkt_import_plugin');

function load_nkt_import_plugin() {
    define('NKT_US_PLUGIN_URL', plugin_dir_url(__FILE__));
    define('NKT_US_PLUGIN_DIR', plugin_dir_path(__FILE__));
   

    require_once NKT_US_PLUGIN_DIR . '/inc/loader.php';
    
}




 /*-------------------------------------------------------------------
| Activation Tags 
 --------------------------------------------------------------------*/


  register_activation_hook(__FILE__, 'nkt_usimprt_activate_print');

  function nkt_usimprt_activate_print() {

      $roles = wp_roles();
      $roles->add_cap( 'caravan_owner', 'manage_import_csv_users' );
      $roles->add_cap( 'contributor', 'manage_import_csv_users' );
      
  }



  /*-------------------------------------------------------------------
  | Deactivate Hook 
  --------------------------------------------------------------------*/

  register_deactivation_hook(__FILE__, 'nkt_usimprt_deactivation_event');

  function nkt_usimprt_deactivation_event() {

      $roles = wp_roles();
      $roles->remove_cap( 'caravan_owner', 'manage_import_csv_users' );
      $roles->remove_cap( 'contributor', 'manage_import_csv_users' );
  }



?>