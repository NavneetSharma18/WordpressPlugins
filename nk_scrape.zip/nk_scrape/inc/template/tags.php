<?php
require_once NKT_US_PLUGIN_DIR . '/inc/template/header.php';
?>

<div class="table_container">
   <button id="synch_data" class="btn btn-primary" >Sync Data</button>
   <button id="add_tags" class="btn btn-primary" >Add Tags</button>
   <table id="tag_tbl" class="display table table-resposive table-bordered" style="width:100%">
 
        <thead>
            <tr>
                <th>Sr No.</th>
                <th>Tag Name</th>
                <th>Created At</th>
                <th>Is Schedule</th>
                <th>View</th>
                
            </tr>
        </thead>
        <tbody>

          <?php if(null != $tag_alls):?>

             <?php foreach ($tag_alls as $key => $value):?>
               <tr>
                <td><?= $key +=1?></td>
                <td><?= $value->tag_name?></td>
                <td><?= $value->created_at?></td>
                <td><?= $value->is_schedule?></td>
                <td><button class="btn btn-danger del_tag" data-tag-id ="<?= $value->tag_id?>">Delete</button>&nbsp;&nbsp;&nbsp;<a class="btn btn-default" href="<?= admin_url().'/admin.php?page=nk_view_tags_view_data&tag_id='.$value->tag_id ?>" data-tag-id ="<?= $value->tag_id?>">View</a></td>
                
               </tr>
             <?php endforeach; ?>

          <?php endif; ?>
           
            
           
        </tbody>
        
    </table>

</div>

<div id="loader">
</div>


<!-- --------------------------------------------------------------->


  <!-- Modal Add Tag -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Tag</h4>
        </div>

        <div class="modal-body">
          <form action="javascript:void(0);" id="add_tag_form">
            <div class="form-group">
              <label for="email">Select Tag:</label>
              <select class="form-control" name="tags_name" id="tag_name">
                <option></option>
                <option>Option 1</option>
              </select>
            </div>
            <div class="form-group">
               <label for="email">Do You Want To Schedule Tag:</label>
              <select class="form-control" name="is_schedule" id="is_schedule">
                <option></option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>
            <button type="submit" class="btn btn-default" id="submit_tag">Submit</button>
          </form>

        </div>


        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

<style type="text/css">
  	 #loader {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.75) url("<?php echo plugin_dir_url( __FILE__ ) .'/loading.gif'; ?>") no-repeat center center;
            z-index: 10000;
        }
</style>

<?php
require_once NKT_US_PLUGIN_DIR . '/inc/template/footer.php';
?>
