<?php
require_once NKT_US_PLUGIN_DIR . '/inc/template/header.php';
?>

<?php
function to_time_ago( $time )
{
   $difference = (strtotime(date('Y-m-d h:i:s') ) - $time);
   if( $difference < 1 )
   {
      return 'less than only a second ago';
   }
   $time_rule = array (
      12 * 30 * 24 * 60 * 60 => 'year',
      30 * 24 * 60 * 60 => 'month',
      24 * 60 * 60 => 'day',
      60 * 60 => 'hour',
      60 => 'minute',
      1 => 'second'
   );
   foreach( $time_rule as $sec => $my_str )
   {
      $res = $difference / $sec;
      if( $res >= 1 )
      {
         $t = round( $res );
         return $t . ' ' . $my_str .
         ( $t > 1 ? 's' : '' ) . ' ago';
      }
   }
}
  
?>

<div class="table_container">
   
   <button id="back_tag" class="btn btn-primary" onclick="history.back()">Back</button>
   <table id="tag_view_data" class="display table table-resposive table-bordered" style="width:100%">
 
        <thead>
            <tr>
                      <th>Sr No.</th>
                      <th>Name</th>
                      <th>Address</th>
                      <th>Website</th>
                      <th>Start Date</th>
                      <th>End Date</th>
                      <th>Venue</th>
                      <th>Updated At</th>
                      <th>Last Updated</th>

                      
                  </tr>
        </thead>
        <tbody>

          <?php if(null != $data):?>

             <?php foreach ($data as $key => $value): ?>
               <tr>
                <td><?= $key +=1?></td>
                <td><?= $value['name']?></td>
                <td><?= $value['address']?></td>
                <td><?= $value['website']?></td>
                <td><?= ($value['start_date'] == '1970-01-01 12:00:00')?'':date('Y-m-d',strtotime($value['start_date']) )?></td>
                <td><?= ($value['end_date'] == '1970-01-01 12:00:00')?'':date('Y-m-d',strtotime($value['end_date']) )?></td>
                <td><?= $value['venue']?></td>
                 <td><?= $value['created_at']?></td>
                <td><?= to_time_ago(strtotime(date('d-m-Y h:i:s',strtotime($value['created_at'] )) ) );?></td>
                
               </tr>
             <?php endforeach; ?>

          <?php endif; ?>
           
            
           
        </tbody>
        
    </table>

</div>


<?php
require_once NKT_US_PLUGIN_DIR . '/inc/template/footer.php';
?>




