<?php



class nkt_scrape {  

    
   /*---------------------------------------------------------
   |  Construct function for adding hook
   ----------------------------------------------------------*/

    public function __construct() {
        
     add_action( 'admin_menu', array($this,'nk_add_admin_page') );

     add_action( 'wp_ajax_nopriv_get_tag_data', array($this,'get_tag_data') );
     add_action( 'wp_ajax_get_tag_data', array($this,'get_tag_data' ) );

     add_action( 'wp_ajax_nopriv_add_tag_data', array($this,'add_tag_data') );
     add_action( 'wp_ajax_add_tag_data', array($this,'add_tag_data' ) );

     add_action( 'wp_ajax_nopriv_delete_tag', array($this,'delete_tag') );
     add_action( 'wp_ajax_delete_tag', array($this,'delete_tag' ) );

     add_action( 'wp_ajax_nopriv_trigger_tag_view', array($this,'trigger_tag_view') );
     add_action( 'wp_ajax_trigger_tag_view', array($this,'trigger_tag_view' ) );

     add_action( 'wp_ajax_nopriv_view_tag_data', array($this,'view_tag_data') );
     add_action( 'wp_ajax_view_tag_data', array($this,'view_tag_data' ) );
     

    }



    /*---------------------------------------------------------
    |  Common function scrape and adding tag view data table
    ----------------------------------------------------------*/


     public function scrape_tag_vie_data_by_tag_id($id=null){

      header("Content-Type: text/plain"); 
      global $wpdb;
      $tablename = $wpdb->prefix.'nkt_view_tags_data';

       $link = "https://www.mtishows.com/maprefresh?field_production_show_target_id=".$id;
       $html_dom = file_get_html($link, false);
       $table_rows = $html_dom->find('.views-table tbody tr');

       $result = false;

       foreach($table_rows as $tabl_key => $table_row) {

          $name_element   = $table_row->find('.views-field-title-1', 0);
          $addrss_street_element      = $table_row->find('.thoroughfare', 0);
          $addrss_locality_element    = $table_row->find('.locality', 0);
          $addrss_state_element       = $table_row->find('.state', 0);
          $addrss_postal_code_element = $table_row->find('.postal-code', 0);
          $website_element            = $table_row->find('td a', 0);
          $stsrtdate_element          = $table_row->find('.date-display-start', 0);
          $enddate_element            = $table_row->find('.date-display-end', 0);
          $venue_element              = $table_row->find('td', 4);

          $name    = $name_element->innertext;
          $address = $addrss_street_element->innertext.' '.$addrss_locality_element->innertext.' '.$addrss_state_element->innertext.' '.$addrss_postal_code_element->innertext;
          if(@$website_element->innertext){
            $website = $website_element->getAllAttributes()['href'];
          }else{
            $website = @$website_element->innertext;
          }
          
          $s_date  = $stsrtdate_element->innertext;
          $e_date  = $enddate_element->innertext;
          $venue   = $venue_element->innertext;

          $data = array(
               
              'tag_id'      => $id,
              'name'        => $name,
              'address'     => $address,
              'website'     => $website,
              'start_date'  => date('Y-m-d h:i:s',strtotime($s_date) ),
              'end_date'    => date('Y-m-d h:i:s',strtotime($e_date) ), 
              'venue'       => $venue,
              'created_at'  => date('Y-m-d h:i:s'),
              'is_cron_run' => 'Y',
               );
          

           $result = $wpdb->insert($tablename,$data); 

          
       }  // end of scrape data loop

       return $result;

    }



    /*---------------------------------------------------------
    |  Data sync callback function from admin 
    ----------------------------------------------------------*/

     public function trigger_tag_view() {

         $data =[];

         if(isset($_POST['is_schdl']) && $_POST['is_schdl'] == 'yes'){

                header("Content-Type: text/plain"); 
                global $wpdb;
                $tablename = $wpdb->prefix.'nkt_add_remove_tags';
                $tag_alls  = $wpdb->get_results( "SELECT * FROM $tablename WHERE `is_schedule` = 'yes'");
                
              
                $result = [];
                if(null != $tag_alls){

                      foreach ($tag_alls as $key => $value) {

                        
                         
                           $id        = $value->tag_id;
                           $tablename = $wpdb->prefix.'nkt_view_tags_data';
                           $wpdb->delete($tablename,['tag_id' => $id],['%s'],);

                           $this->scrape_tag_vie_data_by_tag_id($id);
                          


                      } // endof tags loop

                      $data['status'] = true;
                      $data['msg']    = "Data sync successfully !";

                }else{
                       $data['status'] = false;
                       $data['msg']    = "Sorry no tag added please add tag first !";
                } // if tag is null



          }else{
             $data['status'] = false;
             $data['msg']    = "Invalid Param found !";
          } // isset
          
          echo json_encode($data);
          exit; 
             
        
     }


    /*---------------------------------------------------------
    |  Get last updated cron time
    ----------------------------------------------------------*/


   public function nk_time_elapsed_string($datetime, $full = false) {

            $now = new DateTime;
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);

            $diff->w = floor($diff->d / 7);
            $diff->d -= $diff->w * 7;

            $string = array(
                'y' => 'year',
                'm' => 'month',
                'w' => 'week',
                'd' => 'day',
                'h' => 'hour',
                'i' => 'minute',
                's' => 'second',
            );
            foreach ($string as $k => &$v) {
                if ($diff->$k) {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                } else {
                    unset($string[$k]);
                }
            }

            if (!$full) $string = array_slice($string, 0, 1);
            return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

   
    /*---------------------------------------------------------
    |  Delete tag 
    ----------------------------------------------------------*/


    public function delete_tag(){

        $data   = [];

        if(isset($_POST['tag_id']) && !empty($_POST['tag_id'])){

            global $wpdb;

            $id        = $_POST['tag_id'];
            $tablename = $wpdb->prefix.'nkt_add_remove_tags';
            $wpdb->delete( $tablename, array( 'tag_id' => $id ) ); 

            $tablename = $wpdb->prefix.'nkt_view_tags_data';
            $wpdb->delete( $tablename, array( 'tag_id' => $id ) ); 

            $data['status']  = true;
            $data['options'] = "Tag deleted succesfully!"; 
        }
        echo json_encode($data); 
        exit;
    }


    /*---------------------------------------------------------
    |  Adding new tags
    ----------------------------------------------------------*/

    public function add_tag_data(){

        $data   = [];

        if(isset($_POST['tag_name']) && !empty($_POST['tag_name']) && isset($_POST['tag_val']) && !empty($_POST['tag_val']) && isset($_POST['is_schdl']) && !empty($_POST['is_schdl']) ){

            $tag_val  = filter_var($_POST['tag_val'], FILTER_VALIDATE_INT);
            $tag_name = filter_var($_POST['tag_name'], FILTER_SANITIZE_STRING);
            $is_schdl = filter_var($_POST['is_schdl'], FILTER_SANITIZE_STRING);


            global $wpdb;
            $tablename = $wpdb->prefix.'nkt_add_remove_tags';

            $check_tag_exist  = $wpdb->get_results( "SELECT * FROM $tablename WHERE tag_id = $tag_val" );
            if(count($check_tag_exist) > 0){

                $data['status']  = false;
                $data['options'] = "Tag already exist!";

            }else{

                    $wpdb->insert( $tablename, array(
                        'tag_name'    => $tag_name, 
                        'tag_id'      => $tag_val, 
                        'is_schedule' => $is_schdl,
                        'created_at'  => date('Y-m-d h:i:s'), 
                         ),
                        array( '%s', '%s', '%s', '%s' ) 
                    );

                   $id = $tag_val;
                   $this->scrape_tag_vie_data_by_tag_id($id);
                   $data['status']  = true;
                   $data['options'] = "Tag added successfully!";

            }
        
            

            


        }else{
             $data['status']  = false;
             $data['options'] = "Tag not added";
        }

        echo json_encode($data); 
        exit;
    }


    /*---------------------------------------------------------
    |  Get all the tags dropdown menu
    ----------------------------------------------------------*/

    public function get_tag_data(){

        header("Content-Type: text/plain"); 
        $link       = "https://www.mtishows.com/maprefresh";
        $html_dom   = file_get_html($link, false);
        $table_rows = $html_dom->find('#edit-field-production-show-target-id option'); 

        $result = '';
        $data   = [];
        foreach($table_rows as $key => $table_row) {

            $option_val  = $table_row->getAttribute('value');
            $option_name = $table_row->innertext;
            $result .= "<option value='".$option_val."' data-name='".$option_name."'>".$option_name."</option>";
        }
        $data['status']  = true;
        $data['options'] = $result;

        echo json_encode($data); 
        exit;      
    
    }


   /*---------------------------------------------------------
    |  Plugin add admin menu page
    ----------------------------------------------------------*/

    public function nk_add_admin_page(){

        add_menu_page( 'Scraped Data List', 'Scraped Data List', 'manage_options', 'scraped_data_page_call', array($this,'scraped_data_page_call'));

        add_submenu_page( null,'View Tags Data','View Tags Data','manage_options','nk_view_tags_view_data',array($this,'nk_view_tags_view_data'));
    }


    /*---------------------------------------------------------
    |  admin menu page callback function
    ----------------------------------------------------------*/

    public function nk_view_tags_view_data(){

      if(isset($_GET['tag_id']) && !empty($_GET['tag_id'])){

         $id   = $_GET['tag_id'];
         $data = $this->view_tag_data($id);

         ob_start();
         require_once NKT_US_PLUGIN_DIR . '/inc/template/tags_view.php';
         $tag_views = ob_get_contents();
         ob_end_clean(); 
         echo $tag_views;


      }else{

       wp_die("You are not allowed to you this page");
      }

      
    }



    /*---------------------------------------------------------
    |  Get all the tag data from the DB
    ----------------------------------------------------------*/

     public function view_tag_data($id=null){


           global $wpdb;

           $result         = [];
           $tablename      = $wpdb->prefix.'nkt_view_tags_data';
           $tag_view_alls  = $wpdb->get_results( "SELECT * FROM $tablename WHERE tag_id = $id order by start_date DESC" );

            
            $tag_view_alls = json_decode(json_encode($tag_view_alls), true);

            return $tag_view_alls;
        

      }



    /*---------------------------------------------------------
    |  List all tag data table
    ----------------------------------------------------------*/

    public function scraped_data_page_call(){


        global $wpdb;
        $tablename = $wpdb->prefix.'nkt_add_remove_tags';
        $tag_alls  = $wpdb->get_results( "SELECT * FROM $tablename order by created_at DESC" );
        
        ob_start();
        require_once NKT_US_PLUGIN_DIR . '/inc/template/tags.php';
        $email_content = ob_get_contents();
        ob_end_clean(); 
        echo $email_content;

    }

    
   

}

new nkt_scrape();
