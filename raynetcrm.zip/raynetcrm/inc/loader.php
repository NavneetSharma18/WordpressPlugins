<?php



class ray_raynetCRM {  

    

    public function __construct() {
        

    add_action( 'elementor_pro/forms/form_submitted', array($this, 'check_submit_data'));

         

    }

    

 

   public function check_submit_data( $module ) {


    if(!empty($_POST['form_id']))
    {






                      $formId       = $_POST['post_id'];
                      $category     = '';

                      if(get_locale() == 'sk_SK'){

                        $category = '150';

                      }else{
                        $category = '149';
                      }


                      if($formId == '649'){

                      	  $name          =$_POST['form_fields']['email'];
	                      $lastName      =$_POST['form_fields']['field_bceff6f'];
	                      $telephone     =$_POST['form_fields']['field_cf17f0c'];
	                      $email         =$_POST['form_fields']['field_f8ea834'];
	                      $notice        = "$name $lastName <br/>$telephone<br/>$email<br/>";
	                      $data     =  array (
                                        "topic"=> $name,
                                        'firstName' => $name,
                                        'lastName' => $lastName,
                                        'notice' => $notice,
                                        'category' => $category,
                                        'contactSource' => '79',
                                        'contactInfo' => 
                                        array (
                                          'email' => $email,
                                          'tel1' => $telephone,
                                          'tel1Type' => 'Mobil',
                                          'tel2' => '',
                                          'tel2Type' => '',
                                          'www' => '',
                                          'fax' => '',
                                          'otherContact' => ''
                                        ),
                                        'address' =>
                                        array(
                                         'city'    => '',
                                         'province' => ''
                                        )


                                      );


                      }elseif ($formId == '137') {

                      	  $name          =$_POST['form_fields']['email'];
	                      $telephone     =$_POST['form_fields']['field_cf17f0c'];
	                      $email         =$_POST['form_fields']['field_f8ea834'];
	                      $notice        = "$name <br/>$telephone<br/>$email<br/>";
	                      $data     =  array (
                                        "topic"=> $name,
                                        'firstName' => $name,
                                        'lastName' => '',
                                        'notice' => $notice,
                                        'category' => $category,
                                        'contactSource' => '79',
                                        'contactInfo' => 
                                        array (
                                          'email' => $email,
                                          'tel1' => $telephone,
                                          'tel1Type' => 'Mobil',
                                          'tel2' => '',
                                          'tel2Type' => '',
                                          'www' => '',
                                          'fax' => '',
                                          'otherContact' => ''
                                        ),
                                        'address' =>
                                        array(
                                         'city'    => '',
                                         'province' => ''
                                        )


                                      );
                      	
                      }else
                      {
                      	  $name          =$_POST['form_fields']['name'];
	                      $telephone     =$_POST['form_fields']['field_b95b062'];
	                      $email         =$_POST['form_fields']['email'];
	                      $message       =$_POST['form_fields']['message'];
	                      $notice        = "$name <br/>$telephone<br/>$email<br/>$message";
	                      $data     =  array (
                                        "topic"=> $name,
                                        'firstName' => $name,
                                        'lastName' => '',
                                        'notice' => $notice,
                                        'category' => $category,
                                        'contactSource' => '79',
                                        'contactInfo' => 
                                        array (
                                          'email' => $email,
                                          'tel1' => $telephone,
                                          'tel1Type' => 'Mobil',
                                          'tel2' => '',
                                          'tel2Type' => '',
                                          'www' => '',
                                          'fax' => '',
                                          'otherContact' => ''
                                        ),
                                        'address' =>
                                        array(
                                         'city'    => '',
                                         'province' => ''
                                        )


                                      );

                      }
                  

                      
                      

                    

                    

                    
            

                    $j=json_encode($data);   
                    
                                                                                                           
                                                                                  
                     $curl = curl_init();

                        curl_setopt_array($curl, array(
                          CURLOPT_URL => "https://app.raynet.cz/api/v2/lead/",
                          CURLOPT_RETURNTRANSFER => true,
                          CURLOPT_ENCODING => "",
                          CURLOPT_MAXREDIRS => 10,
                          CURLOPT_TIMEOUT => 30,
                          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                          CURLOPT_CUSTOMREQUEST => "PUT",
                          CURLOPT_POSTFIELDS => "$j",
                          CURLOPT_HTTPHEADER => array(
                            "Authorization: Basic bXlob21lQGNlbnR1cnkyMS5jejpNeUhvbWVSZXluZXQyMQ==",
                            "content-type: application/json",
                            "postman-token: 6474879d-dd6d-10f7-da22-00032d52f69e",
                            "x-instance-name: myhome"
                          ),
                        ));
                        
                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                        
                        curl_close($curl);
                        
                       /* if ($err) {
                          echo "cURL Error #:" . $err;
                        } else {
                          echo $response;
                        }
                        die;
                        */
                           
                              

    }
    
   
   

    

}





}

new ray_raynetCRM();
