<?php

namespace Raynet\Client;


class RaynetGenericException extends \Exception {

} 