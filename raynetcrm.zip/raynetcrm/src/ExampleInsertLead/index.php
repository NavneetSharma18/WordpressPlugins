<?php

use Raynet\Client\RaynetCrmRestClient;
use Raynet\Client\RaynetGenericException;

require_once "../../vendor/autoload.php";

$instanceName = 'instanceName'; // name of your RAYNET CRM
$userName = 'userName'; // user name (email address)
$apiKey = 'apiKey'; // API key (from Application settings -> For developers -> API keys -> NEW API KEY)

$resultCode = null;
$resultMsg = null;

try {
    $crm = new RaynetCrmRestClient($instanceName, $userName, $apiKey);

    $territoryValues = $crm->getCodelistValues('territory');
    $contactSourceValues = $crm->getCodelistValues('contactSource');
    $leadCategoryValues = $crm->getCodelistValues('leadCategory');
    $telTypeValues = $crm->getCodelistValues('telType');
    $countryValues = $crm->getCodelistValues('country');

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = array(
            'topic' => $_REQUEST['topic'],
            'priority' => $_REQUEST['priority'],
            'companyName' => $_REQUEST['companyName'],
            'firstName' => $_REQUEST['firstName'],
            'lastName' => $_REQUEST['lastName'],
            'contactSource' => $_REQUEST['contactSource'],
            'category' => $_REQUEST['category'],
            'notice' => $_REQUEST['notice'],
            'address' => array(
                'street' => $_REQUEST['street'],
                'city' => $_REQUEST['city'],
                'province' => $_REQUEST['province'],
                'zipCode' => $_REQUEST['zipCode'],
                'country' => $_REQUEST['country'],
            ),
            'territory' => $_REQUEST['territory'],
            'contactInfo' => array(
                'tel1' => $_REQUEST['tel1'],
                'tel2' => $_REQUEST['tel2'],
                'tel1Type' => $_REQUEST['tel1Type'],
                'tel2Type' => $_REQUEST['tel2Type'],
                'email' => $_REQUEST['email'],
                'www' => $_REQUEST['www'],
                'fax' => $_REQUEST['fax'],
                'otherContact' => $_REQUEST['otherContact']
            ),
            'notificationEmailAddresses' => array('email@domain.com'),
            'notificationMessage' => 'Lead has been created via web form'
        );

        $resultCode = $crm->createLead($data);
    }
} catch (RaynetGenericException $e) {
    $resultCode = $e->getCode();
    $resultMsg = $e->getMessage();
}
?>
 <?php if ($resultCode !== null && $resultCode <= 201): ?>
            <div class="alert alert-success">Lead has been successfully created.</div>
        <?php elseif ($resultCode !== null && $resultCode >= 400):?>
            <div class="alert alert-danger">Error <?php echo $resultCode; ?>: <div><?php echo $resultMsg; ?></div></div>
        <?php endif; ?>