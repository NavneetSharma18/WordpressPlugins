<?php

/*

 * Plugin Name: Raynet CRM

 * Plugin URI: 

 * Description: Raynet 

 * Author: Navneet

 * Text Domain: ray-raynet

 * Version: 1.0

 * Requires at least: 4.4

 * Tested up to: 5.2.2

 */

defined( 'ABSPATH' ) or exit;

if (!function_exists('pr')) {
    function pr($data) {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}



add_action('plugins_loaded', 'load_ray_raynet_plugin');

function load_ray_raynet_plugin() {
    define('RAY_RAYNET_PLUGIN_URL', plugin_dir_url(__FILE__));
    define('RAY_RAYNET_PLUGIN_DIR', plugin_dir_path(__FILE__));

    define('RAY_RAYNET_INSTANCE_NAME', 'epcr');
    define('RAY_RAYNET_USERNAME', 'josef.sedivy@nextreality.cz');
    define('RAY_RAYNET_APIKEY', 'crm-db120ca9146c40d9ab04cfe26e9d0b7c');
   
    

    require_once RAY_RAYNET_PLUGIN_DIR . '/inc/loader.php';
}



/*  Activation hook */
register_activation_hook(__FILE__, 'pws_activate_print');

function pws_activate_print() {


   
    
}

/*  Deactivation hook  */
register_deactivation_hook(__FILE__, 'pws_deactivation_event');

function pws_deactivation_event() {

}




?>