 /*-------------------------------------------------------------
  |  Intialize datatable
  -------------------------------------------------------------*/

      $(document).ready(function () {
          $('#loader').hide();
          $('#tag_tbl').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });


           $('#tag_view_data').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            } );

              /*-------------------------------------------------------------
              |  Schedule data sync
              -------------------------------------------------------------*/


                  function checkDate() {
                        var date = new Date();
                        console.log(date.getDay());
                        console.log(date.getHours());
                        console.log(date.getMinutes());
                        if(date.getDay() === 7 && date.getHours() === 13 && date.getMinutes() === 59 ) {
                            $("#synch_data").trigger('click');
                            console.log('run success navneet');
                        }
                  }
                  
                  setInterval(checkDate, 30000);
                      
                  });

      /*-------------------------------------------------------------
      |  Get Tag Options
      -------------------------------------------------------------*/

      $("#add_tags").click(function(){
         $('#loader').show();
         
         $.ajax({
            type : "GET",
            url : admin_url,
            data : {action: "get_tag_data"},
            dataType:"json",
            success: function(res) {
              console.log(res.status);
              if(res.status == true){
                $("#tag_name").html(res.options);
                $('#myModal').modal('show');
                $('#loader').hide();
              }
            }
        });
        
      });

      /*-------------------------------------------------------------
      |  Add Tag Form validation
      -------------------------------------------------------------*/

      $("#add_tag_form").validate({
          // Specify validation rules
          rules: {
            tags_name: "required",
            is_schedule: "required",
            
          },
          messages: {
            tags_name: {
            required: "Please select tag",
           },
           is_schedule: {
            required: "Please select scheduling",
           },      

          },
        
        });

      /*-------------------------------------------------------------
      |  Add Tag
      -------------------------------------------------------------*/

      $("#submit_tag").click(function(){

         $('#loader').show();
         var tag_name  =  $('#tag_name').find(":selected").text();
         var tag_val   =  $('#tag_name').val();
         var is_schdl  =  $('#is_schedule').val();

         $.ajax({
            type : "POST",
            url : admin_url,
            data : {action: "add_tag_data","tag_name":tag_name,"tag_val":tag_val,"is_schdl":is_schdl},
            dataType:"json",
            success: function(res) {
              $('#loader').hide();
              toastr.success(res.options);
              if(res.status == true){

                $('#myModal').modal('hide');
                location.reload();
              }
            }
        });

      })

      /*-------------------------------------------------------------
      |  Delete Tag
      -------------------------------------------------------------*/

      $(".del_tag").click(function(){

        $('#loader').show();

        if(confirm("Are you sure you want to delete?")){

          var tag_id = $(this).attr('data-tag-id');
          $.ajax({
            type : "POST",
            url : admin_url,
            data : {action: "delete_tag","tag_id":tag_id},
            dataType:"json",
            success: function(res) {
              $('#loader').hide();
              toastr.success(res.options);
              if(res.status == true){
                location.reload();
              }
            }
        });


        }else{
             $('#loader').hide();
             return false;
        }


      })

      /*-------------------------------------------------------------
      |  View Tag Data
      -------------------------------------------------------------*/
      
      $(".view_tag_data").click(function(){

        $('#loader').show();

        var tag_id = $(this).attr('data-tag-id');
          $.ajax({
            type : "POST",
            url : admin_url,
            data : {action: "view_tag_data","tag_id":tag_id},
            dataType:"json",
            success: function(res) {
              
              if(res.status == true){
                $("#append_view_data").html(res.options);
                $("#view_tag_modal").modal('show');
              }else{
                toastr.success(res.msg);
              }
              $('#view_tag_data_tbl').DataTable();
              $('#loader').hide();

            }
        });

      })
     
     /*-------------------------------------------------------------
      |  Sync Tag Data
      -------------------------------------------------------------*/
      
      $("#synch_data").click(function(){
          //alert('hi');return false;

           $('#loader').show();
            var is_schdl = "yes";
              $.ajax({
                type : "POST",
                url : admin_url,
                data : {action: "trigger_tag_view","is_schdl":is_schdl},
                dataType:"json",
                success: function(res) {
                  
                  toastr.success(res.msg);
                  $('#loader').hide();

                }
            });


      });    