<?php ?>

<link rel="stylesheet" type="text/css" href="<?php echo plugin_dir_url( __FILE__ ) .'/css/jquery.dataTables.min.css' ?>">
<link rel="stylesheet" href="<?php echo plugin_dir_url( __FILE__ ) .'/css/bootstrap.min.css'?>">
<link href="<?php echo plugin_dir_url( __FILE__ ) .'/css/toastr.css'?>" rel="stylesheet"/>
<link href="<?php echo plugin_dir_url( __FILE__ ) .'/css/style.css'?>" rel="stylesheet"/>
<script type="text/javascript">
	var admin_url = "<?= admin_url('admin-ajax.php') ?>";
</script>