<?php

/*

 * Plugin Name: SCRAPE URL DATA 

 * Plugin URI: http://nktechnologys.com/

 * Description: This plugin is use for scraping the data from the given url based on the html tags

 * Author: Navneet (05navneetsharma@gmail.com)

 * Text Domain: http://nktechnologys.com/

 * Version: 1.0

 * Requires at least: 4.4

 * Tested up to: 5.2.2

 */

defined( 'ABSPATH' ) or exit;

if (!function_exists('pr')) {
    function pr($data) {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}



add_action('plugins_loaded', 'load_nkt_scrape_plugin');

function load_nkt_scrape_plugin() {
    define('NKT_US_PLUGIN_URL', plugin_dir_url(__FILE__));
    define('NKT_US_PLUGIN_DIR', plugin_dir_path(__FILE__));
   

    require_once NKT_US_PLUGIN_DIR . '/inc/loader.php';
    require_once NKT_US_PLUGIN_DIR . '/inc/main.php';
}


 
  /*-------------------------------------------------------------------
  | Scheduling Tags 
  --------------------------------------------------------------------*/



        add_filter( 'cron_schedules', function ( $schedules ) {
           $schedules['third_days'] = array(
               'interval' =>  3 * 24 * 60 * 60,
               'display' => __( 'Every Third day' )
           );
           return $schedules;
        } );
        add_action( 'init', 'nk_tag_view_update' );
        add_action( 'nk_schedule_view_data_update', 'nk_get_schedule_callback', 1, 1 );

        function nk_tag_view_update() {
            error_log( 'triggered' );
            if ( ! wp_next_scheduled( 'nk_schedule_view_data_update' ) ) {
                wp_schedule_event( time(), 'third_days', 'nk_schedule_view_data_update' );
            }
        }

       function nk_get_schedule_callback() {

        // ini_set('display_errors', 1);
        // ini_set('display_startup_errors', 1);
        // error_reporting(E_ALL);

                $data =[];

         

                header("Content-Type: text/plain"); 
                global $wpdb;
                $tablename = $wpdb->prefix.'nkt_add_remove_tags';
                $tag_alls  = $wpdb->get_results( "SELECT * FROM $tablename WHERE `is_schedule` = 'yes'");
                
              
                $result = [];
                if(null != $tag_alls){

                      foreach ($tag_alls as $key => $value) {

                        
                         
                           $id        = $value->tag_id;
                           $tablename = $wpdb->prefix.'nkt_view_tags_data';
                           $wpdb->delete($tablename,['tag_id' => $id],['%s'],);

                           $link = "https://www.mtishows.com/maprefresh?field_production_show_target_id=".$id;
                           $html_dom = file_get_html($link, false);
                           $table_rows = $html_dom->find('.views-table tbody tr');

                           foreach($table_rows as $tabl_key => $table_row) {

                              $name_element   = $table_row->find('.views-field-title-1', 0);
                              $addrss_street_element      = $table_row->find('.thoroughfare', 0);
                              $addrss_locality_element    = $table_row->find('.locality', 0);
                              $addrss_state_element       = $table_row->find('.state', 0);
                              $addrss_postal_code_element = $table_row->find('.postal-code', 0);
                              $website_element            = $table_row->find('td a', 0);
                              $stsrtdate_element          = $table_row->find('.date-display-start', 0);
                              $enddate_element            = $table_row->find('.date-display-end', 0);
                              $venue_element              = $table_row->find('td', 4);

                              $name    = $name_element->innertext;
                              $address = $addrss_street_element->innertext.' '.$addrss_locality_element->innertext.' '.$addrss_state_element->innertext.' '.$addrss_postal_code_element->innertext;
                              if(@$website_element->innertext != ''){
                                $website = $website_element->getAllAttributes()['href'];
                              }else{
                                $website = @$website_element->innertext;
                              }
                              
                              $s_date  = $stsrtdate_element->innertext;
                              $e_date  = $enddate_element->innertext;
                              $venue   = $venue_element->innertext;

                              $s_date = date('Y-m-d h:i:s',strtotime($s_date));
                              $e_date = date('Y-m-d h:i:s',strtotime($e_date));

                             $data = array(
                                   
                                            'tag_id'      => $id,
                                            'name'        => $name,
                                            'address'     => $address,
                                            'website'     => $website,
                                            'start_date'  => $s_date,
                                            'end_date'    => $e_date, 
                                            'venue'       => $venue,
                                            'created_at'  => date('Y-m-d h:i:s'),
                                            'is_cron_run' => 'Y',
                                         ); 

                               $wpdb->insert( $tablename,$data); 
      
                              
                           }  // end of scrape data loop


                      } // endof tags loop

                      $data['status'] = true;
                      $data['msg']    = "Data sync successfully !";

                }else{
                       $data['status'] = false;
                       $data['msg']    = "Sorry no tag added please add tag first !";
                } // if tag is null

          
          echo json_encode($data);
          exit; 
             
        
     }

     




 /*-------------------------------------------------------------------
| Activation Tags 
 --------------------------------------------------------------------*/


  register_activation_hook(__FILE__, 'nkt_us_activate_print');

  function nkt_us_activate_print() {

        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        /*------------------------------------------------
        | Tag Table creation
        -------------------------------------------------*/

        $table_name = $wpdb->prefix.'nkt_add_remove_tags';
        $sql = "CREATE TABLE $table_name (
                 `id` int(11) NOT NULL AUTO_INCREMENT,
                 `tag_id` varchar(220) DEFAULT NULL,
                 `tag_name` varchar(220) DEFAULT NULL,
                 `is_schedule` varchar(220) DEFAULT NULL,
                 `created_at` datetime DEFAULT NULL,
                 PRIMARY KEY (`id`)
                ) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1
                ";
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
          require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
          dbDelta($sql);
        }

        /*------------------------------------------------
        | Tag View Table creation
        -------------------------------------------------*/

        $table_name1 = $wpdb->prefix.'nkt_view_tags_data';
        $sql = "CREATE TABLE $table_name1 (
                 `id` int(11) NOT NULL AUTO_INCREMENT,
                 `tag_id` varchar(220) DEFAULT NULL,
                 `name` varchar(220) DEFAULT NULL,
                 `address` varchar(220) DEFAULT NULL,
                 `website` varchar(220) DEFAULT NULL,
                 `start_date` datetime DEFAULT NULL,
                 `end_date` datetime DEFAULT NULL,
                 `venue` varchar(220) DEFAULT NULL,
                 `created_at` datetime DEFAULT NULL,
                 `is_cron_run` varchar(220) DEFAULT NULL,
                 PRIMARY KEY (`id`)
                ) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1
                ";
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name1'") != $table_name1) {
          require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
          dbDelta($sql);
        }
      
  }





  /*-------------------------------------------------------------------
  | Deactivate Hook 
  --------------------------------------------------------------------*/

  register_deactivation_hook(__FILE__, 'nkt_us_deactivation_event');

  function nkt_us_deactivation_event() {

  }


  /*-------------------------------------------------------------------
  | Uninstalled Hook 
  --------------------------------------------------------------------*/
  function nkt_us_plugin_uninstall(){
      global $wpdb;
      $table_name = $wpdb->prefix.'nkt_add_remove_tags';
      $sql = "DROP TABLE IF EXISTS $table_name";
      $wpdb->query($sql);

      $table_name1 = $wpdb->prefix.'nkt_view_tags_data';
      $sql = "DROP TABLE IF EXISTS $table_name1";
      $wpdb->query($sql);
  }

  register_uninstall_hook(__FILE__, 'nkt_us_plugin_uninstall');




?>