<?php  //?>

<script type="text/javascript">
	var admin_url      = "<?= admin_url('admin-ajax.php') ?>";
	var admin_url_page = "<?= admin_url('admin.php?page=manage-hls-list') ?>";
</script>