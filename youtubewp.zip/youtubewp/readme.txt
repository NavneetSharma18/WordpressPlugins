=== Plugin Name ===
Contributors: (HelloLeads, Navneet Sharma)
Tags: HelloLeads, CRM, Lead Generation,
Requires at least: 4.7
Tested up to: 6.0.1
Requires PHP: >7.0
Stable tag: 1.0
License: GPLv2 
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This Plugin provide functionality for connecting the HelloLeads Crm. You can directly create your lead into HelloLeads crm via submitting the CF7 form from your website.



== Frequently Asked Questions ==

= How to connect HelloLeads CRM =

Just enter your email and token key and click on connect button.

= How many filed type it's support for HelloLeads =

 You can download a list of filed mentioned in the PDF on plugin page. Once you connected you can see the demo code and field list PDF.

== Screenshots ==

1. Screen as per shown in this screenshot is used for connecting the HelloLead Crm via credentials email and token
2. After connected, you will see all the HelloLeads List corresponding to CF7 form list you can just select the CF7 from the list against which you want to create a new lead once that CF7 is submmited. You can easily mapping the list to CF7 from this screen.


