<?php

use Stichoza\GoogleTranslate\GoogleTranslate;

class nkt_gtranslate {  

    

    public function __construct() {
        
     add_action('rest_api_init', array($this,'add_api_route')  );

    }

    public function add_api_route(){
        register_rest_route( 'nkt_gtranslate/v1', 'translate/?lang=(?P<category_id>\d+)',array(
                'methods'  => 'GET',
                'callback' => 'translate_text_nkgtranslate'
      ));
    }

    


     public function translate_text_nkgtranslate( $request ) {
         
             echo "<pre>";print_r($request);die;
               

                    $tr = new GoogleTranslate(); // Translates into English
                    $text = 'इंदिरा गांधी शहरी रोजगार गारंटी योजना यह 2022-23 राजस्थान के राज्य के बजट में मुख्यमंत्री अशोक गहलोत द्वारा घोषित एक शहरी रोजगार योजना है। इस योजना के क्रियान्वयन पर सरकार सालाना 800 करोड़ रुपये खर्च करेगी। इस योजना के तहत शहरी क्षेत्रों में रहने वाले लोगों को प्रति वर्ष कम से कम 100 दिन का रोजगार प्रदान किया जाएगा। इसे महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम (मनरेगा) की तर्ज पर तैयार किया गया है।नए दिशानिर्देश नए दिशानिर्देशों के अनुसार, एक व्यक्ति जो 18 से 60 वर्ष के आयु वर्ग में है और स्थानीय निकाय क्षेत्र में रहता है, उसे जन आधार कार्ड के आधार पर पंजीकृत किया जाएगा। जन आधार कार्ड राज्य सरकार द्वारा जारी किया जाएगा और यह योजना के तहत नामांकन के लिए प्राथमिक पात्रता दस्तावेज होगा।नए दिशानिर्देशों के संबंध में चिंताएं अन्य राज्यों के प्रवासी मजदूरों को केवल कोविड-19 महामारी या प्राकृतिक आपदाओं जैसी आपात स्थितियों में ही काम उपलब्ध कराने के प्रावधान पर नागरिक समाज समूहों द्वारा सवाल उठाया जा रहा है। उन्होंने यह भी चिंता जताई कि राज्य के बाहर के लोगों के लिए राज्य द्वारा प्रदान किए गए पात्रता दस्तावेज प्राप्त करना मुश्किल है।';

                    echo $tr->setSource('hi')->setTarget('en')->translate($text);
                    die;
                
         
    }

   
    
   

}

new nkt_gtranslate();
