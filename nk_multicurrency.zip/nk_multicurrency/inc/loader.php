<?php


class nk_multicurrency {  

    

    public function __construct() {
        add_action( 'wp', array($this, 'get_country_data' ) );

    }

  public function get_country_data() {
      
        echo $data = var_export(unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR'])));
        die;

  }


}

new nk_multicurrency();
