<?php
require_once NKT_TBLRES_PLUGIN_DIR . '/inc/template/include/header.php';
$tag_alls = [];
?>
<style type="text/css">
  .table_div {
    padding: 5px;
    margin: 5px;
    background: #c9cbc9;
    border-radius: 5%;
    max-width: 100%;
}
span.tbl_no {
    font-weight: bolder;
    font-size: 20px;
}
p.no_of-people {
    font-size: 17px;
}
#wpcontent{
  background: none !important;
}
.table_container {
    padding: 65px;
    margin-top: 65px;
}
</style>
<div class="main_tbl_div">

<div class="table_container">
<div class="row" id="table_list">


  <?php if(null != $final_arr): ?>
  <?php foreach ($final_arr as $key => $val):  ?>
   <?php  $cordX = $val['cordX'];$cordY = $val['cordY']; if($cordX && $cordY) {$style = "left:$cordX;top:$cordY";}else{$style='';} ?>
<div class="col-md-2" >
  <div class="table_div draggable_tbl" data-postid="<?= $val['order']?>" style="<?= $style?>">
    <span class="tbl_no" id="<?= $val['order']?>">#<?= $val['caravan_id']?></span>
    <p class="no_of-people"><?= ($val['max_people'])?$val['max_people']:'0'?> People</p>
  </div>
</div>
<?php endforeach ;?>
<?php endif; ?>

</div>

<div class="row">
  <div class="col-md-4">
  <button class="btn btn-success" id="save_arrangement">Save Arrangments</button>
</div>
</div>
 

</div>

<div id="loader"></div>

</div>


<style type="text/css">
  	 #loader {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.75) url("<?php echo plugin_dir_url( __FILE__ ) .'/assest/loading.gif'; ?>") no-repeat center center;
            z-index: 10000;
        }
  </style>

<?php
require_once NKT_TBLRES_PLUGIN_DIR . '/inc/template/include/footer.php';
?>
  

<script>


  $(function() {

           var arrg_obj     = {};
           var arrangements = [];
               
           $( ".draggable_tbl" ).draggable({
              containment: '.main_tbl_div',
              start: function( event, ui ) { 
                // nesne sürüklenmeye başladığı anda yapılacak işlemler.
                
               
                },  
                drag: function( event, ui ) {  
                //Sürüklenme anında yapılacak işlemler.
                
                },
                stop: function( event, ui ) {

                 var postid = $(this).attr('data-postid');
                 postT   = ui.position.top
                 posiL   = ui.position.left

                 offsetT = ui.offset.top
                 offsetL = ui.offset.left
                 
                 console.log('evnet offset '+ui.offset.left)
                 arrg_obj = { 'postid':postid,
                              'cord':{
                                'X':posiL,
                                'Y':postT
                              }
                               
                           }
                 arrangements.push(arrg_obj);
                  
                }

              });


           $("#save_arrangement").click(function(){

                    if(arrangements.length){

                          if(confirm("Are you sure want to save ?")){
                               $.ajax({
                                    url:admin_url,
                                    dataType:'json',
                                    method:"POST",
                                    data:{'action':'nk_update_table_order',arrangements:arrangements},
                                    success:function(res)
                                    {
                                       
                                       //$("#loader").hide();
                                      if(res.status == true){
                                        toastr.success(res.msg);
                                      }else{
                                        toastr.error(res.msg);
                                      }
                                      location.reload();
                                       
                                    }
                                });
                           }else{
                                arrangements = [];
                                return false;
                           }
                    }

               
                
           })
     

          

  })





// $(document).ready(function(){
//  $( "#table_list" ).sortable({
//   placeholder : "ui-state-highlight",
//   update  : function(event, ui)
//   {

//     console.log("Position X,Y is: "+event.pageX,event.pageY);
//    var page_id_array = new Array();
//    $('#table_list .tbl_no').each(function(){
//     page_id_array.push($(this).attr("id"));
//    });

//    $("#loader").show();

//    $.ajax({
//     url:admin_url,
//     dataType:'json',
//     method:"POST",
//     data:{'action':'nk_update_table_order',page_id_array:page_id_array},
//     success:function(res)
//     {
//        //location.reload();
//        $("#loader").hide();
//        toastr.success('Order updated');
//     }
//    });
//   }
//  });

// });
</script>