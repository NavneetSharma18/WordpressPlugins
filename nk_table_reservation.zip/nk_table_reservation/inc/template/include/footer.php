<script src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/jquery.min.js'?>"></script>
<script src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/bootstrap.min.js'?>"></script>
<script type="text/javascript" src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/jquery.dataTables.min.js'?>"></script>
<script src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/jquery-ui.js'?>"></script>
<script src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/toastr.js'?>"></script>
<script src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/jquery.validate.js'?>"></script>
<script src="<?= NKT_TBLRES_PLUGIN_URL .'inc/template/include/js/custom.js'?>"></script>