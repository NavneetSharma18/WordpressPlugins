<?php

class NktTableReservation {  

    
   /*---------------------------------------------------------
   |  Construct function for adding hook
   ----------------------------------------------------------*/

    public function __construct() {
        
     add_action( 'admin_menu', array($this,'nk_reserv_table_admin_page') );
     add_action( 'wp_ajax_nopriv_nk_update_table_order', array($this,'nk_update_table_order') );
     add_action( 'wp_ajax_nk_update_table_order', array($this,'nk_update_table_order' ) );
     
    }


    public function nk_update_table_order(){

      if(isset($_POST['arrangements']) && !empty($_POST['arrangements'])){
        
        $arrangements = $_POST["arrangements"];

        //echo "<pre>";print_r($arrangements);die;

        if(null != $arrangements){

          foreach ($arrangements as $key => $val) {
            
            $post_id = $val['postid'];
            $pageX   = $val['cord']['X'];
            $pageY   = $val['cord']['Y'];
            update_post_meta($post_id,'coordinate_x',$pageX);
            update_post_meta($post_id,'coordinate_y',$pageY);
          }
        }

        echo json_encode(['status'=>true,'msg' => 'arrangements saved suucessfully!']);
        die;

      }else{
        echo json_encode(['status'=>false,'msg' => 'Please make some changes in arrangements']);
        die;
      }


    }



   /*---------------------------------------------------------
    |  Plugin add admin menu page
    ----------------------------------------------------------*/

    public function nk_reserv_table_admin_page(){


        global $user_role_name;
        
      if( $user_role_name == 'contributor' || $user_role_name == 'caravan_owner' ){

            add_menu_page( 'Reservation Table List', 'Reservation Table List', 'manage_table_caravan', 'nkt_reservation_table_list', array($this,'nkt_reservation_table_list'));
        }

        

        
    }


    /*---------------------------------------------------------
    |  List table with max people
    ----------------------------------------------------------*/

    public function nkt_reservation_table_list(){

        $posts  = get_posts([
          'post_type'   => 'caravan',
          'post_status' => 'publish',
          'numberposts' => -1,
          'orderby'   => array(

                            'menu_order'=>'ASC',
                           
                           )
          
        ]);

        $final_arr = [];

        foreach ($posts as $key => $val) {

            $post_id     = $val->ID;
            $final_arr[$key]['caravan_id'] = get_post_meta($post_id,'caravan_id',true);
            $final_arr[$key]['max_people'] = get_post_meta($post_id,'max_people',true);
            $final_arr[$key]['cordX']      = get_post_meta($post_id,'coordinate_x',true);
            $final_arr[$key]['cordY']      = get_post_meta($post_id,'coordinate_y',true);
            $final_arr[$key]['order']      = $post_id; 

      }

       //echo "<pre>";print_r($final_arr);

        ob_start();
        require_once NKT_TBLRES_PLUGIN_DIR . '/inc/template/tablelist.php';
        $table_list = ob_get_contents();
        ob_end_clean(); 
        echo $table_list;

    }



    
   

}

new NktTableReservation();