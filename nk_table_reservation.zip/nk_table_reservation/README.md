Scrape Data From Website
======================

This plugin is used for adding a specific tag from the admin dahsboard and after that it will scrape the tags view data based on scheduling functionality. If you want to schedule then you can schedule the tag data every 3 days whichis default functionality. Means it will scrape the schedule data autometically after every three day and update into the Db 

Requirements
------------

* PHP 5 (tested with PHP 5.5, although older should also work)
* Admin user account with API key (API key can be created here: Application settings -> For developers -> API keys -> NEW API KEY)
