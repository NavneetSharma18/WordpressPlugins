<?php
/**
 
 * @package NK Posts
 
 */
 
/*
 
Plugin Name: NK Posts Plugin
 
Plugin URI: https://nktechnologys.com/
 
Description: This is the custom plugin for showing the post on forntend with custom post image uploaded, also provide functionality for searching the post via post title.
add this shortcode in any apge [nk_show_posts]
 
Version: 1.0.0
 
Author: NK Techonologys
 
Author URI: https://nktechnologys.com/
 
License: GPLv2 or later
 
Text Domain: Nkposts
Tested up to: 5.4
 
*/


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
function activate_nk_posts() {
	
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
 */
function deactivate_nk_posts() {
	
}

register_activation_hook( __FILE__, 'activate_nk_posts' );
register_deactivation_hook( __FILE__, 'deactivate_nk_posts' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ). 'inc/loader.php';


?>