<?php 
if ( ! function_exists( 'my_pagination' ) ){
			    function my_pagination() {
			        global $wp_query;

			        $big = 999999999; // need an unlikely integer

			        echo paginate_links( array(
			            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			            'format' => '?paged=%#%',
			            'current' => max( 1, get_query_var('paged') ),
			            'total' => $wp_query->max_num_pages
			        ) );
			    }
                }
 ?>
 <script type="text/javascript">
 	var ajax_url = "<?= admin_url( 'admin-ajax.php' ) ?>";
 </script>
<script language="JavaScript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>

<link href="https://unpkg.com/tailwindcss@2.2.4/dist/tailwind.min.css" rel="stylesheet">
    <style type="text/css">
    	.justify-center{
    		width: 100%;
            max-width: 60% !important;
    	}
    	.btn-widht {
		    max-width: 25%;
		    font-size: 14px;
		}
		.main_wrap{
			margin-top: 80px;
		}
		.post-main-wrap {
		    margin-top: 30px;
		}
		span.page-numbers {
		    border: 1px solid #efefef;
		    padding: 0px 9px;
		    background: #000;
		    color: #fff;
		}
		.pagination_main{
			margin: 0px auto;
			padding-top: 20px;
		}
    	
    </style>


    <div class="flex flex-col justify-center">
      <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline post_title_search" id="post_title_search" type="text" placeholder="Search By post title">
   </div>
    <div class="flex flex-col justify-center main_wrap append_data">

     
     
      	
     
     <?php
	    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

		query_posts(array(
		    'post_type'      => 'post', // You can add a custom post type if you like
		    'paged'          => $paged,
		    'posts_per_page' => 4
		));

		if ( have_posts() ) :
	        while ( have_posts() ) : the_post();

	         $post_id              = get_the_ID();
	         $thumb_url            = wp_get_attachment_url( get_post_thumbnail_id( $post_id ) );
	         $banner_image_id      = get_post_meta($post_id,'post_banner_img',true);
	         $banner_image_url     = '';

	         if($banner_image_id){
	     	  $banner_image_url    = get_the_guid($banner_image_id);
	         }
	        
	?>
	<div class="relative flex flex-col md:flex-row md:space-x-5 space-y-3 md:space-y-0 rounded-xl shadow-lg p-3 max-w-xs md:max-w-3xl mx-auto border border-white bg-white post-main-wrap">
       
       
		            <div class="w-full md:w-1/3 bg-white grid place-items-center">
		             <?php if($thumb_url):?>
			            <img src="<?= $thumb_url?>" alt="tailwind logo" class="rounded-xl" />
			         <?php endif; ?>
			         <?php if(!empty($banner_image_url) ): ?>
			         	<img src="<?= $banner_image_url?>" alt="tailwind logo" class="rounded-xl" />
			         <?php endif; ?>
                   </div>

        

		            <div class="w-full md:w-2/3 bg-white flex flex-col space-y-2 p-3">
				
						<h3 class="font-black text-gray-800 md:text-3xl text-xl">
							<?= the_title();?>
								
						</h3>
						<p class="md:text-lg text-gray-500 text-base">
							<?= the_excerpt(); ?>	
					    </p>
						<a href="<?php echo get_permalink($post_id) ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full btn-widht">Read More</a>
					</div>

		</div>
		<?php endwhile; ?>
            
		  <p class="md:text-lg text-gray-500 text-base pagination_main">  <?php my_pagination(); wp_reset_query();?> </p>

		<?php else : ?>

		    <p class="md:text-lg text-gray-500 text-base">No post found  </p>

		<?php endif; ?>
		 
	</div>

	<script type="text/javascript">
		(function($){

			 var currentRequest = null; 
		   $("#post_title_search").keyup(function() {
		      
		       var name = $('#post_title_search').val();
		       if (name != "") {

		       	    

					currentRequest = $.ajax({
					    type: 'POST',
					    url: ajax_url,
		         	    data: {action:"nk_search_post_by_name",search: name},
					    beforeSend : function()    {           
					        if(currentRequest != null) {
					            currentRequest.abort();
					        }
					    },
					    success: function(data) {
					        var obj = JSON.parse(data);
					        if(obj.res == 'SS'){
					        	$('.append_data').html(obj.append_data);
					        }
					    },
					    error:function(e){
					      // Error
					    }
					});
		       
		        
		       }
		   });

        })(jQuery); 
		
	</script>
