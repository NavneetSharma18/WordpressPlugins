<?php

if (!class_exists('NKPost')) {

     class NKPost{



 	         protected static $instance;

 	         public static function instance()
	         {
	             if (!isset(self::$instance)) {
	                self::$instance = new self();
	             }
	             return self::$instance;
	         }

		     public function __construct()
		     {


		       
		        add_shortcode('nk_show_posts',[$this, 'nk_show_post_callback'], 10);
		        add_action( 'add_meta_boxes', [$this,'nk_multi_media_uploader_meta_box'], 10 );
		        add_action( 'save_post',      [$this,'nk_wc_meta_box_save'], 10 );  
                  add_action( 'wp_ajax_nopriv_nk_search_post_by_name', [$this,'nk_search_post_by_name'] );
			   add_action( 'wp_ajax_nk_search_post_by_name',        [$this,'nk_search_post_by_name'] );
		     }

		     public function nk_multi_media_uploader_meta_box() {
				add_meta_box( 'my-post-box', 'Add Image',[$this, 'multi_media_uploader_meta_box_func'], 'post', 'normal', 'high' );
			}

			public function multi_media_uploader_meta_box_func($post) {
				$banner_img = get_post_meta($post->ID,'post_banner_img',true);
				?>
				<style type="text/css">
					.multi-upload-medias ul li .delete-img { position: absolute; right: 3px; top: 2px; background: aliceblue; border-radius: 50%; cursor: pointer; font-size: 14px; line-height: 20px; color: red; }
					.multi-upload-medias ul li { width: 120px; display: inline-block; vertical-align: middle; margin: 5px; position: relative; }
					.multi-upload-medias ul li img { width: 100%; }
				</style>

				<table cellspacing="10" cellpadding="10">
					<tr>
						<td>Post Image</td>
						<td>
							<?php echo $this->multi_media_uploader_field( 'post_banner_img', $banner_img ); ?>
						</td>
					</tr>
				</table>

				<script type="text/javascript">
					jQuery(function($) {

						$('body').on('click', '.wc_multi_upload_image_button', function(e) {
							e.preventDefault();

							var button = $(this),
							custom_uploader = wp.media({
								title: 'Insert image',
								button: { text: 'Use this image' },
								multiple: true 
							}).on('select', function() {
								var attech_ids = '';
								attachments
								var attachments = custom_uploader.state().get('selection'),
								attachment_ids = new Array(),
								i = 0;
								attachments.each(function(attachment) {
									attachment_ids[i] = attachment['id'];
									attech_ids += ',' + attachment['id'];
									if (attachment.attributes.type == 'image') {
										$(button).siblings('ul').append('<li data-attechment-id="' + attachment['id'] + '"><a href="' + attachment.attributes.url + '" target="_blank"><img class="true_pre_image" src="' + attachment.attributes.url + '" /></a><i class=" dashicons dashicons-no delete-img"></i></li>');
									} else {
										$(button).siblings('ul').append('<li data-attechment-id="' + attachment['id'] + '"><a href="' + attachment.attributes.url + '" target="_blank"><img class="true_pre_image" src="' + attachment.attributes.icon + '" /></a><i class=" dashicons dashicons-no delete-img"></i></li>');
									}

									i++;
								});

								var ids = $(button).siblings('.attechments-ids').attr('value');
								if (ids) {
									var ids = ids + attech_ids;
									$(button).siblings('.attechments-ids').attr('value', ids);
								} else {
									$(button).siblings('.attechments-ids').attr('value', attachment_ids);
								}
								$(button).siblings('.wc_multi_remove_image_button').show();
							})
							.open();
						});

						$('body').on('click', '.wc_multi_remove_image_button', function() {
							$(this).hide().prev().val('').prev().addClass('button').html('Add Media');
							$(this).parent().find('ul').empty();
							return false;
						});

					});

					jQuery(document).ready(function() {
						jQuery(document).on('click', '.multi-upload-medias ul li i.delete-img', function() {
							var ids = [];
							var this_c = jQuery(this);
							jQuery(this).parent().remove();
							jQuery('.multi-upload-medias ul li').each(function() {
								ids.push(jQuery(this).attr('data-attechment-id'));
							});
							jQuery('.multi-upload-medias').find('input[type="hidden"]').attr('value', ids);
						});
					})
				</script>

				<?php
			}

			public function multi_media_uploader_field($name, $value = '') {
				$image = '">Add Media';
				$image_str = '';
				$image_size = 'full';
				$display = 'none';
				$value = explode(',', $value);

				if (!empty($value)) {
					foreach ($value as $values) {
						if ($image_attributes = wp_get_attachment_image_src($values, $image_size)) {
							$image_str .= '<li data-attechment-id=' . $values . '><a href="' . $image_attributes[0] . '" target="_blank"><img src="' . $image_attributes[0] . '" /></a><i class="dashicons dashicons-no delete-img"></i></li>';
						}
					}

				}

				if($image_str){
					$display = 'inline-block';
				}

				return '<div class="multi-upload-medias"><ul>' . $image_str . '</ul><a href="#" class="wc_multi_upload_image_button button' . $image . '</a><input type="hidden" class="attechments-ids ' . $name . '" name="' . $name . '" id="' . $name . '" value="' . esc_attr(implode(',', $value)) . '" /><a href="#" class="wc_multi_remove_image_button button" style="display:inline-block;display:' . $display . '">Remove media</a></div>';
			}

			public function nk_wc_meta_box_save( $post_id ) {
				if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
					return;	
				}

				if( !current_user_can( 'edit_post' ) ){
					return;	
				}
				
				if( isset( $_POST['post_banner_img'] ) ){
					update_post_meta( $post_id, 'post_banner_img', $_POST['post_banner_img'] );
				}
			}


		     public function nk_show_post_callback(){

		     	  ob_start();
		          require plugin_dir_path( __FILE__ ). '../templates/post_template.php';
		          $content = ob_get_clean();
		          return $content;
                

		     }

		     public function nk_search_post_by_name() {

                global $wpdb;
                $data_append = '';
			    if(isset($_POST['search']) && !empty($_POST['search'])){

				        $search = $_POST['search'];
	                    $myposts = $wpdb->get_results("SELECT *  FROM `wp_posts` WHERE `post_type` = 'post' AND `post_title` LIKE '%".$search."%'");

					    foreach ( $myposts as $key => $post ) 
						{   
							
						    $thumb_url       = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
				            $banner_image_id = get_post_meta($post->ID,'post_banner_img',true);
				            $banner_image_url= '';

				            if($banner_image_id){
				     	    $banner_image_url    = get_the_guid($banner_image_id);
				            }

						  $data_append .= '<div class="relative flex flex-col md:flex-row md:space-x-5 space-y-3 md:space-y-0 rounded-xl shadow-lg p-3 max-w-xs md:max-w-3xl mx-auto border border-white bg-white post-main-wrap">';
						  $data_append .= '<div class="w-full md:w-1/3 bg-white grid place-items-center">';
						  if($thumb_url){
						  	$data_append .= '<img src="'.$thumb_url.'" alt="tailwind logo" class="rounded-xl" />';
						  }
						  if($banner_image_url){
						  	$data_append .= '<img src="'.$banner_image_url.'" alt="tailwind logo" class="rounded-xl" />';
						  }
						  $data_append .= '</div>';
						  $data_append .= '<div class="w-full md:w-2/3 bg-white flex flex-col space-y-2 p-3">';
						  $data_append .= '<h3 class="font-black text-gray-800 md:text-3xl text-xl">'.$post->post_title.'</h3>';
						  $data_append .= '<p class="md:text-lg text-gray-500 text-base">'.$post->post_content.'</p>';  
						  $data_append .= '<a href="'.$post->guid.'" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full btn-widht">Read More</a>';
						  $data_append .= '</div>';
						  $data_append .= '</div>';
						  
						  
						}	
			     }


			            
					

						echo json_encode([
							 			  'res'         =>'SS',
							 			  'append_data' => $data_append
						                ]);
						die;
			}
  
	         
     }

	 NKPost::instance();
}

 

?>